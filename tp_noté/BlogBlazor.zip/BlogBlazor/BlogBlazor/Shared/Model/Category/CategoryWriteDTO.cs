namespace BlogBlazor.Shared.Model.Category
{
    public class CategoryWriteDTO
    {
        public string Name { get; set; }
    }
}