namespace BlogBlazor.Shared.Model.Author
{
    public class AuthorLoginReadDTO
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}