using BlogBlazor.Data.Model;

namespace BlogBlazor.Data.Repository
{
    public interface ICategoryRepository : IRepository<Category>
    {
    }
}